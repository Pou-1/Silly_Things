# SILLY THINGS

This mod add a new **Item** to the game !

## Dependencies 🤫

-   [BepInExPack](https://thunderstore.io/c/lethal-company/p/BepInEx/BepInExPack/)
-   [LethalLib](https://thunderstore.io/c/lethal-company/p/Evaisa/LethalLib/)
-   [MoreCompany](https://thunderstore.io/c/lethal-company/p/notnotnotswipez/MoreCompany/)

### Feedback

You can post some suggestions or issues in the mod release page in the as a [github](https://github.com/Pou-1/Silly_Things) issue.

##

# Credits

-   Thanks **Zigzag** for help on the UI and the network !
-   Thanks to AlemanGame for the item model : https://sketchfab.com/3d-models/suitcase-8686e3b8564349fdbbdf166042655036
